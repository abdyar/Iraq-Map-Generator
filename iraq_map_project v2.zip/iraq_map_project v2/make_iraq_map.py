import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.geometry import box
from PIL import Image
import os
import json

def get_script_dir():
    """Returns the absolute path of the directory containing the script."""
    return os.path.dirname(os.path.abspath(__file__))

def load_config(config_path):
    """Loads configuration settings from a JSON file."""
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file not found at {config_path}")
        return None
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON format in {config_path}. Details: {e}")
        return None

def write_bots_json(bots_data, output_path):
    """Writes the bots data to a separate JSON file."""
    try:
        with open(output_path, 'w') as f:
            json.dump(bots_data, f, indent=2)
        print(f"Bots JSON file saved as {output_path}")
    except Exception as e:
        print(f"Error writing bots JSON file: {e}")

def generate_openfront_map(config):
    """
    Generates a map of Iraq that adheres to the OpenFront team's specifications,
    using a configurable JSON file.
    """
    script_dir = get_script_dir()
    
    # Check if required shapefiles exist
    countries_path = os.path.join(script_dir, config['map_data']['countries_file'])
    rivers_path = os.path.join(script_dir, config['map_data']['rivers_file'])
    lakes_path = os.path.join(script_dir, config['map_data']['lakes_file'])

    for file_path in [countries_path, rivers_path, lakes_path]:
        if not os.path.exists(file_path):
            print(f"Error: Required file not found at {file_path}")
            print("Please ensure all shapefiles are in the same folder as this script.")
            return

    # Define the bounding box for Iraq
    iraq_bbox = box(*config['map_settings']['iraq_bbox'])

    try:
        countries = gpd.read_file(countries_path, bbox=iraq_bbox)
        rivers = gpd.read_file(rivers_path, bbox=iraq_bbox)
        lakes = gpd.read_file(lakes_path, bbox=iraq_bbox)
    except Exception as e:
        print(f"A more specific error occurred: {e}")
        return

    iraq = countries[countries.SOVEREIGNT == "Iraq"]
    
    if iraq.empty:
        print("Error: 'Iraq' not found in the countries shapefile. Please check the data.")
        return

    # Calculate aspect ratio
    minx, miny, maxx, maxy = iraq.total_bounds
    aspect_ratio = (maxx - minx) / (maxy - miny)
    fig_width = 10
    fig_height = fig_width / aspect_ratio
    fig, ax = plt.subplots(1, 1, figsize=(fig_width, fig_height))
    
    ax.set_axis_off()
    ax.set_facecolor(tuple(c / 255 for c in config['colors']['plains']))
    
    lakes.to_crs(iraq.crs).plot(ax=ax, color=tuple(c / 255 for c in config['colors']['water']))
    rivers.to_crs(iraq.crs).plot(ax=ax, color=tuple(c / 255 for c in config['colors']['water']), linewidth=0.1)
    iraq.plot(ax=ax, facecolor=(0, 0, 0, 0), edgecolor="black", linewidth=0.5)

    ax.set_xlim(minx, maxx)
    ax.set_ylim(miny, maxy)
    plt.subplots_adjust(left=0, right=1, bottom=0, top=1)
    
    temp_filename = os.path.join(script_dir, "temp_map.png")
    plt.savefig(temp_filename, dpi=300, bbox_inches='tight', pad_inches=0)
    plt.close(fig)

    try:
        img = Image.open(temp_filename)
        img = img.resize((config['map_settings']['width'], config['map_settings']['height']), Image.Resampling.LANCZOS)
        
        final_map_path = os.path.join(script_dir, config['map_settings']['output_filename'])
        img.save(final_map_path)
        os.remove(temp_filename)
    except Exception as e:
        print(f"Error resizing and saving the final map: {e}")
        return

    print(f"OpenFront-compatible map saved as {config['map_settings']['output_filename']}")
    
if __name__ == "__main__":
    config_path = os.path.join(get_script_dir(), 'config.json')
    config_data = load_config(config_path)
    if config_data:
        # Generate the map
        generate_openfront_map(config_data)
        
        # Write the bots.json file
        bots_output_path = os.path.join(get_script_dir(), 'bots.json')
        write_bots_json(config_data['bots'], bots_output_path)
