import os
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.geometry import box

# ----- DEBUGGING SECTION -----
# This part of the code will list all files in the current directory.
# This helps us confirm if the shapefile is actually there from Python's perspective.
print("Files in the current directory:")
for file in os.listdir("."):
    print(file)
print("----------------------------")

# Define the bounding box for Iraq
iraq_bbox = box(38.78, 29.8, 48.78, 37.38)

# Read the shapefiles
countries = gpd.read_file("ne_10m_admin_0_countries.shp", bbox=iraq_bbox)
rivers = gpd.read_file("ne_10m_rivers_lake_centerlines.shp", bbox=iraq_bbox)
lakes = gpd.read_file("ne_10m_lakes.shp", bbox=iraq_bbox)

# Filter for Iraq
iraq = countries[countries.SOVEREIGNT == "Iraq"]

# Create the plot
fig, ax = plt.subplots(1, 1, figsize=(10, 10))

# Plot Iraq's boundaries
iraq.plot(ax=ax, facecolor="none", edgecolor="black", linewidth=1.5, zorder=1)

# Plot lakes
lakes.plot(ax=ax, color="lightblue", zorder=2)

# Plot rivers
rivers.plot(ax=ax, color="blue", linewidth=0.8, zorder=3)

# Set the title and remove axes
ax.set_title("Map of Iraq with Rivers and Lakes", fontsize=16)
ax.set_axis_off()

# Save the map
plt.savefig("iraq_map.png", dpi=300)

print("Iraq map saved as iraq_map.png")